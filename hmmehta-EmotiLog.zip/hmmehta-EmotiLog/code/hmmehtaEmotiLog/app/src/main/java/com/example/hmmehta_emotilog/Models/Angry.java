package com.example.hmmehta_emotilog.Models;

public class Angry implements Emotion{
    public String getName(){
        return "Angry";
    }
}
