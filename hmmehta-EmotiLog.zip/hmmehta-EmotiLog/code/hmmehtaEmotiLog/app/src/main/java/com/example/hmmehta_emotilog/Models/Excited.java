package com.example.hmmehta_emotilog.Models;

public class Excited implements Emotion{
    public String getName(){
        return "Excited";
    }
}
