package com.example.hmmehta_emotilog.Fragments;

import android.content.Context;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.view.ViewGroup;

import com.example.hmmehta_emotilog.MainActivity;
import com.example.hmmehta_emotilog.Models.Log;
import com.example.hmmehta_emotilog.Models.User;
import com.example.hmmehta_emotilog.R;

import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class EventsFragment extends Fragment {

    private LinearLayout eventsContainer;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_events, container, false);
        eventsContainer = view.findViewById(R.id.eventsContainer);

        MainActivity activity = (MainActivity) getActivity();
        if (activity != null) {
            displayEvents(activity.getCurrentUser().viewAllLogs());
        }

        return view;
    }

    public void refreshEvents() {
        MainActivity activity = (MainActivity) getActivity();
        if (activity != null) {
            displayEvents(activity.getCurrentUser().viewAllLogs());
        }
    }

    private void displayEvents(List<Log> logs) {
        eventsContainer.removeAllViews();

        if (logs.isEmpty()) {
            TextView empty = new TextView(getContext());
            empty.setText("No emotions logged yet.\nStart by selecting an emotion!");
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(16, 16, 16, 16);
            eventsContainer.addView(empty);
            return;
        }

        // Sort newest → oldest
        Collections.sort(logs, new Comparator<Log>() {
            @Override
            public int compare(Log l1, Log l2) {
                return l2.getDateTime().compareTo(l1.getDateTime());
            }
        });

        Context ctx = getContext();
        for (Log log : logs) {
            CardView card = new CardView(ctx);
            LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            );
            cardParams.setMargins(0, 0, 0, 16);
            card.setLayoutParams(cardParams);
            card.setRadius(12);
            card.setCardElevation(6);

            LinearLayout row = new LinearLayout(ctx);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(16, 16, 16, 16);
            row.setGravity(Gravity.CENTER_VERTICAL);

            // Emoji
            TextView emoji = new TextView(ctx);
            emoji.setText(getEmojiForEmotion(log.getEmotion().getName()));
            emoji.setTextSize(32);
            emoji.setPadding(0, 0, 16, 0);

            // Vertical container: emotion + timestamp
            LinearLayout col = new LinearLayout(ctx);
            col.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams colParams = new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1
            );
            col.setLayoutParams(colParams);

            TextView emotionName = new TextView(ctx);
            emotionName.setText(log.getEmotion().getName());
            emotionName.setTextSize(18);

            TextView timestamp = new TextView(ctx);
            timestamp.setText(formatDate(log.getDateTime()) + " at " + formatTime(log.getDateTime()));
            timestamp.setTextSize(14);
            timestamp.setTextColor(0xFF888888); // gray

            col.addView(emotionName);
            col.addView(timestamp);

            row.addView(emoji);
            row.addView(col);
            card.addView(row);
            eventsContainer.addView(card);
        }
    }

    private String formatDate(Date date) {
        return new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(date);
    }

    private String formatTime(Date date) {
        return new SimpleDateFormat("hh:mm:ss a", Locale.getDefault()).format(date);
    }

    private String getEmojiForEmotion(String emotion) {
        switch (emotion) {
            case "Happy": return "😊";
            case "Sad": return "😢";
            case "Angry": return "😡";
            case "Loved": return "❤️";
            case "Grateful": return "🙏";
            case "Excited": return "🤩";
            default: return "🙂";
        }
    }
}