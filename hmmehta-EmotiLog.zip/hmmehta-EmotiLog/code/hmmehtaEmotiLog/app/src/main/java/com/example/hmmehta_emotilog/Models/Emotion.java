package com.example.hmmehta_emotilog.Models;

public interface Emotion {
    public String getName();
}
