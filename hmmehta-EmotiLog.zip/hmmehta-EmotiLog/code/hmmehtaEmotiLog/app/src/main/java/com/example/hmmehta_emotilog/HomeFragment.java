package com.example.hmmehta_emotilog;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.example.hmmehta_emotilog.Models.Angry;
import com.example.hmmehta_emotilog.Models.Excited;
import com.example.hmmehta_emotilog.Models.Grateful;
import com.example.hmmehta_emotilog.Models.Happy;
import com.example.hmmehta_emotilog.Models.Log;
import com.example.hmmehta_emotilog.Models.Loved;
import com.example.hmmehta_emotilog.Models.Sad;
import com.example.hmmehta_emotilog.Models.User;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link HomeFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class HomeFragment extends Fragment {

    private User sharedUser;

    public HomeFragment() { }

    @Nullable
    @Override
    public View onCreateView( LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_home, container, false);

        // Access shared user from MainActivity
        MainActivity activity = (MainActivity) getActivity();
        if (activity != null) {
            sharedUser = activity.getCurrentUser();
        }

        // button: Happy
        Button happyButton = view.findViewById(R.id.button_happy);
        happyButton.setOnClickListener(v -> {
            sharedUser.addNewLog(new Log(new Happy()));
            Toast.makeText(getContext(), "Logged: Happy", Toast.LENGTH_SHORT).show();

            // Tell Summary Adapter to update
            notifyEventsChanged(activity);
        });

        // button: Sad
        Button sadButton = view.findViewById(R.id.button_sad);
        sadButton.setOnClickListener(v -> {
            sharedUser.addNewLog(new Log(new Sad()));
            Toast.makeText(getContext(), "Logged: Sad", Toast.LENGTH_SHORT).show();

            // Tell Summary Adapter to update
            notifyEventsChanged(activity);

        });

        // button: Loved
        Button lovedButton = view.findViewById(R.id.button_loved);
        lovedButton.setOnClickListener(v -> {
            sharedUser.addNewLog(new Log(new Loved()));
            Toast.makeText(getContext(), "Logged: Loved", Toast.LENGTH_SHORT).show();

            // Tell Summary Adapter to update
            notifyEventsChanged(activity);

        });

        // button: Happy
        Button gratefulButton = view.findViewById(R.id.button_grateful);
        gratefulButton.setOnClickListener(v -> {
            sharedUser.addNewLog(new Log(new Grateful()));
            Toast.makeText(getContext(), "Logged: Grateful", Toast.LENGTH_SHORT).show();

            // Tell Summary Adapter to update
            notifyEventsChanged(activity);

        });

        // button: Sad
        Button angryButton = view.findViewById(R.id.button_angry);
        angryButton.setOnClickListener(v -> {
            sharedUser.addNewLog(new Log(new Angry()));
            Toast.makeText(getContext(), "Logged: Angry", Toast.LENGTH_SHORT).show();

            // Tell Summary Adapter to update
            notifyEventsChanged(activity);

        });

        // button: Loved
        Button excitedButton = view.findViewById(R.id.button_excited);
        excitedButton.setOnClickListener(v -> {
            sharedUser.addNewLog(new Log(new Excited()));
            Toast.makeText(getContext(), "Logged: Excited", Toast.LENGTH_SHORT).show();

            // Tell Summary Adapter to update
            notifyEventsChanged(activity);

        });

        return view;

    }

    private void notifyEventsChanged(MainActivity activity){
        // Tell Summary and Event Adapter to update
        if (activity != null) {
            activity.notifySummaryChanged();
            activity.notifyEventsChanged();
        }
    }

}