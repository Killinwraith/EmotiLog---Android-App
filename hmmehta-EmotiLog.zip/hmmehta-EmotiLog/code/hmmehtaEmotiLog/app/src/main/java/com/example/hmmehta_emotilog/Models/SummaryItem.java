package com.example.hmmehta_emotilog.Models;

public class SummaryItem {
    private String emotionName;
    private int count;
    private String emoji;

    public SummaryItem(String emotionName, int count, String emoji) {
        this.emotionName = emotionName;
        this.count = count;
        this.emoji = emoji;
    }

    public String getEmotionName() { return emotionName; }
    public int getCount() { return count; }
    public String getEmoji() { return emoji; }
}
