package com.example.hmmehta_emotilog.Models;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class User {

    private List<Log> logs;

    public User() {
        this.logs = new ArrayList<Log>();
    }

    public void addNewLog(Log log){
        if (logs != null){
            this.logs.add(log);
        }
    }

    public List<Log> viewAllLogs() {
        return this.logs;
    }

}
