package com.example.hmmehta_emotilog.Models;

public class Grateful implements Emotion{
    public String getName(){
        return "Grateful";
    }
}
