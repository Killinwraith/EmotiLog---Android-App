package com.example.hmmehta_emotilog.Adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.hmmehta_emotilog.Models.SummaryItem;
import com.example.hmmehta_emotilog.R;

import java.util.List;

public class SummaryAdapter extends RecyclerView.Adapter<SummaryAdapter.SummaryViewHolder> {

    private List<SummaryItem> summaryList;

    public SummaryAdapter(List<SummaryItem> summaryList) {
        this.summaryList = summaryList;
    }

    public void setData(List<SummaryItem> newSummaryList) {
        this.summaryList = newSummaryList;
        notifyDataSetChanged();  // tell RecyclerView to redraw
    }

    @NonNull
    @Override
    public SummaryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_summary, parent, false);
        return new SummaryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SummaryViewHolder holder, int position) {
        SummaryItem item = summaryList.get(position);

        int totalLogs = 0;
        for (SummaryItem s : summaryList) totalLogs += s.getCount();
        int maxCount = 0;
        for (SummaryItem s : summaryList) maxCount = Math.max(maxCount, s.getCount());

        double percentage = (item.getCount() * 100.0) / totalLogs;
        int barPercentage = (int) ((item.getCount() * 100.0) / maxCount);

        holder.emotionEmoji.setText(item.getEmoji());
        holder.emotionName.setText(item.getEmotionName());
        holder.emotionCount.setText(item.getCount() + " times (" + String.format("%.1f", percentage) + "%)");
        holder.emotionProgress.setProgress(barPercentage);
    }

    static class SummaryViewHolder extends RecyclerView.ViewHolder {
        TextView emotionEmoji, emotionName, emotionCount;
        ProgressBar emotionProgress;

        public SummaryViewHolder(@NonNull View itemView) {
            super(itemView);
            emotionEmoji = itemView.findViewById(R.id.emotionEmoji);
            emotionName = itemView.findViewById(R.id.emotionName);
            emotionCount = itemView.findViewById(R.id.emotionCount);
            emotionProgress = itemView.findViewById(R.id.emotionProgress);
        }
    }

    @Override
    public int getItemCount() {
        return summaryList.size();
    }

}