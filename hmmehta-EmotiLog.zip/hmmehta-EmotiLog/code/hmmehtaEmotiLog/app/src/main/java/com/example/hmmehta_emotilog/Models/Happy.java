package com.example.hmmehta_emotilog.Models;

public class Happy implements Emotion{
    public String getName(){
        return "Happy";
    }
}
