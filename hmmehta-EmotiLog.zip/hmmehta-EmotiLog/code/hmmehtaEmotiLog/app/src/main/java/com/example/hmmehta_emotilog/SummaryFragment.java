package com.example.hmmehta_emotilog.Fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.hmmehta_emotilog.MainActivity;
import com.example.hmmehta_emotilog.Models.Log;
import com.example.hmmehta_emotilog.Models.User;
import com.example.hmmehta_emotilog.R;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SummaryFragment extends Fragment {

    private LinearLayout summaryContainer;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_summary, container, false);
        summaryContainer = view.findViewById(R.id.summaryContainer);

        MainActivity activity = (MainActivity) getActivity();
        if (activity != null) {
            User user = activity.getCurrentUser();
            displaySummary(user.viewAllLogs());
        }

        return view;
    }

    private void displaySummary(List<Log> logs) {
        summaryContainer.removeAllViews();

        if (logs.isEmpty()) {
            TextView emptyView = new TextView(getContext());
            emptyView.setText("No data to summarize yet. Start logging emotions!");
            emptyView.setPadding(16, 16, 16, 16);
            summaryContainer.addView(emptyView);
            return;
        }

        // Count emotions
        Map<String, Integer> counts = new HashMap<>();
        for (Log log : logs) {
            String emotion = log.getEmotion().getName();
            counts.put(emotion, counts.getOrDefault(emotion, 0) + 1);
        }

        int totalLogs = logs.size();

        // Build a row for each emotion
        LayoutInflater inflater = LayoutInflater.from(getContext());
        for (Map.Entry<String, Integer> entry : counts.entrySet()) {
            View itemView = inflater.inflate(R.layout.item_summary, summaryContainer, false);

            TextView emojiView = itemView.findViewById(R.id.emotionEmoji);
            TextView nameView = itemView.findViewById(R.id.emotionName);
            TextView countView = itemView.findViewById(R.id.emotionCount);
            ProgressBar progressBar = itemView.findViewById(R.id.emotionProgress);

            String emotion = entry.getKey();
            int count = entry.getValue();
            int percentage = (int) ((count * 100.0f) / totalLogs);

            emojiView.setText(getEmojiForEmotion(emotion));
            nameView.setText(emotion);
            countView.setText(count + " (" + percentage + "%)");
            progressBar.setProgress(percentage);

            summaryContainer.addView(itemView);
        }
    }

    public void refreshSummary() {
        MainActivity activity = (MainActivity) getActivity();
        if (activity != null) {
            displaySummary(activity.getCurrentUser().viewAllLogs());
        }
    }

    private String getEmojiForEmotion(String emotion) {
        switch (emotion) {
            case "Happy": return "😊";
            case "Sad": return "😢";
            case "Angry": return "😡";
            case "Loved": return "❤️";
            case "Grateful": return "🙏";
            case "Excited": return "🤩";
            default: return "🙂";
        }
    }
}