package com.example.hmmehta_emotilog;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.hmmehta_emotilog.Models.Log;
import com.example.hmmehta_emotilog.R;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class EventAdapter extends RecyclerView.Adapter<EventAdapter.EventViewHolder> {

    private List<Log> logs;

    public EventAdapter(List<Log> logs) {
        this.logs = logs;
    }

    @NonNull
    @Override
    public EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_event, parent, false);
        return new EventViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EventViewHolder holder, int position) {
        Log log = logs.get(position);

        holder.emojiView.setText(getEmojiForEmotion(log.getEmotion().getName()));
        holder.emotionView.setText(log.getEmotion().getName());

        String timestamp = formatDate(log.getDateTime()) + " at " + formatTime(log.getDateTime());
        holder.timestampView.setText(timestamp);
    }

    @Override
    public int getItemCount() {
        return logs.size();
    }

    static class EventViewHolder extends RecyclerView.ViewHolder {
        TextView emojiView, emotionView, timestampView;

        EventViewHolder(@NonNull View itemView) {
            super(itemView);
            emojiView = itemView.findViewById(R.id.eventEmoji);
            emotionView = itemView.findViewById(R.id.eventEmotion);
            timestampView = itemView.findViewById(R.id.eventTimestamp);
        }
    }

    private String formatDate(Date date) {
        return new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(date);
    }

    private String formatTime(Date date) {
        return new SimpleDateFormat("hh:mm:ss a", Locale.getDefault()).format(date);
    }

    private String getEmojiForEmotion(String emotion) {
        switch (emotion) {
            case "Happy": return "😊";
            case "Sad": return "😢";
            case "Angry": return "😡";
            case "Loved": return "❤️";
            case "Grateful": return "🙏";
            case "Excited": return "🤩";
            default: return "🙂";
        }
    }
}