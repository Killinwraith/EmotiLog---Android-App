package com.example.hmmehta_emotilog;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.example.hmmehta_emotilog.Fragments.EventsFragment;
import com.example.hmmehta_emotilog.Fragments.SummaryFragment;

public class ViewPagerAdapter extends FragmentStateAdapter {

    private final HomeFragment homeFragment;
    private final EventsFragment eventsFragment;
    private final SummaryFragment summaryFragment;

    public ViewPagerAdapter(@NonNull FragmentActivity fragmentActivity) {
        super(fragmentActivity);
        homeFragment = new HomeFragment();
        eventsFragment = new EventsFragment();
        summaryFragment = new SummaryFragment();
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position) {
            case 0: return homeFragment;
            case 1: return eventsFragment;
            case 2: return summaryFragment;
            default: return homeFragment;
        }
    }

    @Override
    public int getItemCount() {
        return 3; // 3 tabs
    }

    // Add getters so MainActivity can access the fragments
    public EventsFragment getEventsFragment() {
        return eventsFragment;
    }

    public SummaryFragment getSummaryFragment() {
        return summaryFragment;
    }
}