package com.example.hmmehta_emotilog;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import com.example.hmmehta_emotilog.Models.User;
import com.example.hmmehta_emotilog.ViewPagerAdapter;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    TabLayout tabLayout;
    ViewPager2 viewPager;
    ViewPagerAdapter adapter;

    private User currentUser;  // Shared object

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize shared User
        currentUser = new User();

        tabLayout = findViewById(R.id.tab_layout);
        viewPager = findViewById(R.id.view_pager);

        adapter = new ViewPagerAdapter(this);
        viewPager.setAdapter(adapter);

        new TabLayoutMediator(tabLayout, viewPager,
                (tab, position) -> {
                    switch (position) {
                        case 0:
                            tab.setText("Home");
                            break;
                        case 1:
                            tab.setText("Events");
                            break;
                        case 2:
                            tab.setText("Summary");
                            break;
                    }
                }).attach();
    }

    public User getCurrentUser() {
        return currentUser;
    }

    //public void notifySummaryChanged() {
    //    List<Fragment> fragments = getSupportFragmentManager().getFragments();
    //    for (Fragment fragment : fragments) {
    //        if (fragment instanceof com.example.hmmehta_emotilog.Fragments.SummaryFragment) {
    //            ((com.example.hmmehta_emotilog.Fragments.SummaryFragment) fragment).refreshSummary();
    //        }
    //    }
   // }
    public void notifyEventsChanged() {
        if (adapter != null) {
            adapter.getEventsFragment().refreshEvents();
        }
    }

    public void notifySummaryChanged() {
        if (adapter != null) {
            adapter.getSummaryFragment().refreshSummary();
        }
    }

}