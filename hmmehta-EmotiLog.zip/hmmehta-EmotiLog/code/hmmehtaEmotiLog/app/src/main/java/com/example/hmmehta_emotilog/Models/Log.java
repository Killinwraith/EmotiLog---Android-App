package com.example.hmmehta_emotilog.Models;

import java.util.Date;

public class Log {
    private Emotion emotion;
    private Date dateTime;

    public Log (Emotion emotion){
        this.emotion = emotion;
        this.dateTime = new Date();
    }

    public Emotion getEmotion() {
        return this.emotion;
    }

    public Date getDateTime() {
        return this.dateTime;
    }
}
